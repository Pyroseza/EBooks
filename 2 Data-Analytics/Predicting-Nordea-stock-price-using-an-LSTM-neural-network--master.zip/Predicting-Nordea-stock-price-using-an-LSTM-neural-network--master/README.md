# Predicting-Nordea-stock-price-using-an-LSTM-neural-network-
Using an 80/20 split in the historical 10-year data daily closing prices of Nordea Bank stock where predicted using a LSTM network based on data observed in the past 30 days for each prediction.
The second notebook uses the same model applied to Bitcoin prices but data only from the past two years, when BTC has been at its most volatile.
